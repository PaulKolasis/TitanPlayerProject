/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.titan.bll;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Paul
 */
public class Library {
   
   List<Song> songs;
   
   public Library(){
       songs = new ArrayList<>();
   }
    public void addSong(Song songToAdd){
       songs.add(songToAdd);
        
    }
    /**
     *
     * @return
     */
    public int songCount() {
       return songs.size();
   }

  }