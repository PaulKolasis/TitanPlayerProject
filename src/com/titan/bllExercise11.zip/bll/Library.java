/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.titan.bll;

import java.util.List;
import java.util.ArrayList;

/**
 *
 * @author Paul
 */
public class Library {
  List<Song> songs;
    
    public Library(){
        songs = new ArrayList<>();
    }
    /**
     *
     * @param songToAdd
     */
    public void addSong(Song songToAdd){
        songs.add(songToAdd);
    }
    
   public int songCount(){
       return songs.size();
   }
}
